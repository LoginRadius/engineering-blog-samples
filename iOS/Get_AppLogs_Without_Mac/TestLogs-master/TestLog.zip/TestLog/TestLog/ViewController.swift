//
//  ViewController.swift
//  TestLog
//
//  Created by Tavni Jain on 2020-07-13.
//  Copyright © 2020 Tavni Jain. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var textfield1: UITextField!
    @IBOutlet var textfield2: UITextField!
    @IBOutlet var sumButton: UIButton!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var buttonSendLog: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("these are dummy logs")
        print("saved in log file")
        print("which you have got by mail from your app user's device")

        sumButton.isEnabled = false /// Disable the button first thing
        [textfield1, textfield2].forEach {
            $0.addTarget(self, action: #selector(editingChanged(_:)), for: .editingChanged) /// add targets to handle the events (in your case it listens for the 'editingChanged' event )
        }
        
    }
    @objc func editingChanged(_ textField: UITextField) {
        
        /// Here we just loop through all our textfields
        for each in  [textfield1, textfield2] {
            if let text = each?.text { /// Just make sure the textfields text is not nil
                if text.count < 1 {
                    // If the textfiels text has no value in, then we keep the button disabled and return
                    sumButton.isEnabled = false
                    return
                }
            } else {
                /// Else if the text field's text is nill, then return and keep the button disabled
                sumButton.isEnabled = false
                return
            }
        }
        
        sumButton.isEnabled = true /// If the code reaches this point, it means the textfields passed all out checks and the button can be enabled
    }
    
    @IBAction func sum(_ sender: Any) {
        let one = textfield1.text!
        let two = textfield2.text!
        
        guard let oneInt = Int(one), let twoInt = Int(two) else {
            print("Whatever was in that text fields, couldn't be converted to an Int")
            label.text = "Be sure to add numbers."
            return
        }
        
        let total = oneInt + twoInt
        
        label.text = "\(total)"
    }
    @IBAction func pressForLogs(_ sender: Any) {
        allOptions()
    }
    func allOptions() {
        let alert = UIAlertController(title: "Please Select an Option", message: nil, preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Log Mail", style: .default , handler:{ (UIAlertAction)in
            self.shareDocument(documentPath: logFilePath)
        }))
        
        alert.addAction(UIAlertAction(title: "dismis", style: .cancel, handler:{ (UIAlertAction)in
            print("User click Dismiss button")
        }))
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
    
    // this is to share file //
    func shareDocument(documentPath: String) {
        if FileManager.default.fileExists(atPath: documentPath){
            let fileURL = URL(fileURLWithPath: documentPath)
            let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView=self.view
            present(activityViewController, animated: true, completion: nil)
        }
        else {
            print("Document was not found")
        }
    }
}



