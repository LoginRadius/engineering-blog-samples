//
//  AppDelegate.swift
//  TestLog
//
//  Created by Tavni Jain on 2020-07-13.
//  Copyright © 2020 Tavni Jain. All rights reserved.
//

import UIKit
//Globals
public var logFilePath:String!
func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    let output = items.map { "*\($0)"}.joined(separator: " ")
    //Swift.print(output, terminator: terminator)
    NSLog(output)
}

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    @IBOutlet var window:UIWindow?;


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        printTheDataAtLogFile()
        // Override point for customization after application launch.
        return true
    }
//this is writing app logs into a file
   func printTheDataAtLogFile() {
    logFilePath = NSTemporaryDirectory().appending(String.init(format: "%@.log",Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as! String)) as String
       freopen((logFilePath as NSString).cString(using: String.Encoding(rawValue: String.Encoding.ascii.rawValue).rawValue)!, "a+", stderr)
   }

}

